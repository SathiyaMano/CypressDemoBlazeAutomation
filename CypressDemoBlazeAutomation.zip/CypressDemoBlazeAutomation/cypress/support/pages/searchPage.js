class SearchPage {
    visit() {
      cy.visit('https://magento.softwaretestingboard.com/');
    }
  
    searchProduct(productName) {
      cy.get('#search').type(`${productName}{enter}`);
    }
  
    validateResults(productName) {
      cy.contains('.product-item', productName).should('be.visible');
    }
  }
  
  export default SearchPage;
  