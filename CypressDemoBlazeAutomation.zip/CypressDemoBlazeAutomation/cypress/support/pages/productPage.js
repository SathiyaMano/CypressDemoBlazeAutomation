class productPage {
    visit() {
      cy.visit('https://magento.softwaretestingboard.com/');
    }
    
      getProduct(itemNumber) {
         return cy.xpath(`(//li[@class='product-item'])[${itemNumber}]`);
        // return cy.get('li.product-item').eq(itemNumber - 1);

      }
    
      addToCartButton(itemNumber) {
        // return cy.xpath(`(//*[text()='Add to Cart'])[${itemNumber}]`);
        return cy.get('button').contains('Add to Cart').eq(itemNumber - 1);

      }
    
      getSizeOptions() {
        // return cy.xpath('//*[@class="swatch-option text"]');
        return cy.get('[class="swatch-option text"]');

      }
    
      selectSize(size) {
         return cy.xpath(`//*[text()='Size']/parent::div/div/div[text()='${size}']`);
      //  return cy.get('div').contains('Size').parent().find('div').contains(size);

      }
    
      selectColor(color) {
        return cy.xpath(`//div[@class='swatch-option color' and @aria-label='${color}']`);
        // return cy.get('div.swatch-option.color[aria-label="' + color + '"]');

      }
    
      addToCartButtonMain() {
       return cy.xpath('//button[@id="product-addtocart-button"]');
        // return cy.get('button#product-addtocart-button');

      }
    
      goToHomePage() {
       return cy.xpath('//a[text()="Home"]');
        // return cy.get('a').contains('Home');

      }
    }
  
    export default new productPage();
  