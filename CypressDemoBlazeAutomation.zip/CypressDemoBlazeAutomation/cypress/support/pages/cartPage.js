class CartPage {
    verifyCartItemQuantity(productName, quantity) {
      cy.contains('.cart.item', productName).find('input.qty').should('have.value', quantity);
    }
  
    verifyTotalPrice(expectedTotalPrice) {
        cy.get('span:contains("Cart Subtotal")').should('contain', expectedPrice);
    }
  
    proceedToCheckout() {
      cy.get('button[title="Proceed to Checkout"]').click();
    }
  }
  
  export default CartPage;
  