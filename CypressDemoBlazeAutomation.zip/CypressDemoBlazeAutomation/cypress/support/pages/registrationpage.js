class RegistrationPage {
    visit() {
      cy.visit('https://magento.softwaretestingboard.com/');
    }
  
    clickCreateAccount() {
    //   cy.get('.header.content a[href*="https://magento.softwaretestingboard.com/customer/account/create"]',{ timeout: 10000 }).should('be.visible').click();
    // }
   
    cy.get('body > div.page-wrapper > header > div.panel.wrapper > div > ul > li:nth-child(3) > a').click();
    }
  
    fillFirstName(firstName) {
      cy.get('#firstname').type(firstName);
    }
  
    fillLastName(lastName) {
      cy.get('#lastname').type(lastName);
    }
  
    fillEmail(email) {
      cy.get('#email_address').type(email);
    }
  
    fillPassword(password) {
      cy.get('#password').type(password);
    }
  
    fillConfirmPassword(password) {
      cy.get('#password-confirmation').type(password);
    }
  
    submitRegistration() {
      // cy.get('button[title="Create an Account"]').click();
      cy.get('#form-validate > div > div.primary > button > span').click();
    }
  }
  
  export default RegistrationPage;
  