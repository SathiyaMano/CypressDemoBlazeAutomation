class WishlistPage {
    visit() {
      cy.visit('https://magento.softwaretestingboard.com/');
    }
  
    addToWishlist(productName) {
      cy.get(`#maincontent > div.columns > div > div.widget.block.block-static-block > div.block.widget.block-products-list.grid > div > div > ol > li:nth-child(1) > div > div > div.product-item-inner > div > div.actions-secondary > a.action.towishlist`).click();
    }
  
    viewWishlist() {
      cy.get('.header.content a[href*="wishlist"]').click();
    }
  
    checkoutFromWishlist() {
      cy.get('button[title="Proceed to Checkout"]').click();
    }
  }
  
  export default WishlistPage;
  