class LoginPage {
    visit() {
      cy.visit('https://magento.softwaretestingboard.com/');
    }
  
    clickSignIn() {
      // cy.get('.header.content a[href*="customer/account/login"]').click();
      cy.get('body > div.page-wrapper > header > div.panel.wrapper > div > ul > li.authorization-link > a').click();
    }
  
    fillEmail(email) {
      cy.get('#email').type(email);
    }
  
    fillPassword(password) {
      cy.get('#pass').type(password);
    }
  
    submitLogin() {
      cy.get('button[class="action login primary"]').click();
    }
  
    verifyLogin() {
      cy.get('.logged-in').should('be.visible');
    }
  }
  
  export default LoginPage;
  