import './commands';

const { merge } = require('mochawesome-merge');
const { create } = require('mochawesome-report-generator');
require('cypress-xpath');
module.exports = (on, config) => {
  on('after:run', (results) => {
    return merge({ files: ['./cypress/reports/*.json'] }).then(report => {
      return create(report, {
        reportDir: './cypress/reports',
        reportFilename: 'report',
        
      });
    });
  });
};
