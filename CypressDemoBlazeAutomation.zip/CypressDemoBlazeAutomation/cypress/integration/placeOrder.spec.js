import ProductPage from '../support/pages/productPage';

describe('Place Order with Multiple Products', () => {
  const productPage = new ProductPage();
  const data = require('../fixtures/data.json');

  it('should add products to cart and place order', () => {
    productPage.visit();

    data.products.forEach(product => {
      productPage.addProductToCart(product.name);
    });

    productPage.goToCart();
    productPage.verifyPriceCalculation('$250.00');
    productPage.placeOrder();
  });
});
