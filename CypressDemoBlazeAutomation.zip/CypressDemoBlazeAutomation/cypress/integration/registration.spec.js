import RegistrationPage from '../support/pages/registrationpage';
import LoginPage from '../support/pages/loginpage';

describe('Registration Flow with Login Validation', () => {
  const registrationPage = new RegistrationPage();
  const loginPage = new LoginPage();
  const data = require('../fixtures/data.json');

  it('should register and validate login', () => {
    // Visit registration page
    registrationPage.visit();
    registrationPage.clickCreateAccount();

    // Fill registration form
    registrationPage.fillFirstName(data.registration.firstName);
    registrationPage.fillLastName(data.registration.lastName);
    registrationPage.fillEmail(data.registration.email);
    registrationPage.fillPassword(data.registration.password);
    registrationPage.fillConfirmPassword(data.registration.password);
    registrationPage.submitRegistration();

    // Verify login
    loginPage.visit();
    loginPage.clickSignIn();
    loginPage.fillEmail(data.registration.email);
    loginPage.fillPassword(data.registration.password);
    loginPage.submitLogin();
    loginPage.verifyLogin();
  });
});
