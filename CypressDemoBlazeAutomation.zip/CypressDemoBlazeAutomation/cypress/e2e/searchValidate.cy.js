import SearchPage from '../support/pages/searchPage';

describe('Search and Validate Results', () => {
  const searchPage = new SearchPage();
  const data = require('../fixtures/data.json');

  it('should search for a product and validate results', () => {
    searchPage.visit();
    searchPage.searchProduct(data.searchProduct);
    searchPage.validateResults(data.searchProduct);
  });
});
