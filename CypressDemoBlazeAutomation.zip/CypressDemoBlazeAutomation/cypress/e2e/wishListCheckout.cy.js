import WishlistPage from "../support/pages/wishListpage";
import ProductPage from "../support/pages/productPage";


describe('Add Products in Wishlist and Checkout from Wishlist', () => {
  const wishlistPage = new WishlistPage();
  const data = require('../fixtures/data.json');

  it('should add products to wishlist and checkout', () => {
    wishlistPage.visit();

    data.wishlistProducts.forEach(product => {
      wishlistPage.addToWishlist(product.name);
    });

    wishlistPage.viewWishlist();
    wishlistPage.checkoutFromWishlist();
  });
});
