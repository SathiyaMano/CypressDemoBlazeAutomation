import ProductPage from '../support/pages/productPage';

describe('Place order with multiple products', () => {
  const addItemToCart = (itemNumber) => {
    ProductPage.getProduct(itemNumber).trigger('mouseover');
    cy.wait(2000);
    ProductPage.addToCartButton(itemNumber).click();

    let sizeCount;
    ProductPage.getSizeOptions().its('length').then((size) => {
      sizeCount = size;
      cy.log('Stored element count:', sizeCount);
    });

    if (sizeCount > 0) {
      let size = [];

      for (let s = 1; s <= sizeCount; s++) {
        ProductPage.getSizeOptions().each(($div) => {
          size.push($div.text().trim());
        }).then(() => {
          cy.log('Collected Text:', size);
        });
      }

      let selectAvailableSize = Math.floor(Math.random() * size.length);
      let selectedSize = size[selectAvailableSize];

      ProductPage.selectSize(selectedSize).click();
    }

    const colors = ["Blue", "S", "M", "XL"];
    let selectAvailableColor = Math.floor(Math.random() * colors.length);
    let selectedColor = colors[selectAvailableColor];

    ProductPage.selectColor(selectedColor).click();
    ProductPage.addToCartButtonMain().click();
    ProductPage.goToHomePage().click();
  };

  it('should place an order with multiple products and apply price calculation checks', () => {
    const size = 5; // Adjust the size as needed

    for (let i = 1; i <= size; i++) {
      addItemToCart(i);
    }

    // You can add additional assertions and price calculation checks here
  });
});
