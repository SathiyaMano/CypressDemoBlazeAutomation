# Demoblaze UI Tests

This project uses Cypress to automate the UI tests for the "Sign In" flow and "Add to Cart" functionality on https://magento.softwaretestingboard.com/

## Tech Stack

- **Cypress**: A JavaScript End-to-End testing framework.

## Setup

1. Install dependencies:
    
    InstallNodejs
    Install VisualStudio
    Create folder for project and open in VScode

   # open cmd/terminal execute below command
    npm -i init for creating package.json file
    
    #Install Cypress
    npm install cypress --save -dev
    ```

2. Open Cypress:
    
    npx cypress open
    ```

## Tests

Test Case (A): Registration flow with login valida4on
Test Case (B): Place order with mul4ple products (apply price calculation checks)
Test Case (C): Add products in Wishlist and checkout from wishlist
Test Case (D): Search and validate results

## Run Tests

To run the tests, use the following command:
```sh
npx cypress run


#Configuration



